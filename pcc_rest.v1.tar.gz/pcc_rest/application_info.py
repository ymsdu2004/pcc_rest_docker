#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# application_info.py
# 2014-10-24
#

class AppInfo(object):
    NAME = 'PCC-REST'
    VERSION = '1.0.0'
    REVISION = 59188
    BUILDER = 'NetPosa'
    DEFAULT_PORT = 8088
