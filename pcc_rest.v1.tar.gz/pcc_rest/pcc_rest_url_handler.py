#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_url_handler.py
# 2014-11-05
#

import os
import urlparse
import urllib2
import json
import rest_util
from pcc_rest_concrete_api import *
from pcc_rest_ret_content_tmpl import *
from rest_file_uploader import post_form_content_handler2
from pcc_rest_concrete_exception import *
from pcc_rest_exception import PccBaseException
from pcc_rest_logger import PCC_LOG

# 列出PCC概述信息  -> GET
def pcc_rest_main_handler(environ):
    PCC_LOG.DEBUG('pcc_rest_main_handler -> /pcc')
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    ########################################################
    raise APINotImplemented('API not implemented yet')
    ########################################################
    
    return (code, header, content)

# 列出系统信息概述  -> GET
def pcc_rest_system_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_system_handler -> /pcc/system')
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    ########################################################
    raise APINotImplemented('API not implemented yet')
    ########################################################
    
    return (code, header, content)

# 获取PCC属性信息 -> GET
def pcc_rest_system_property_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_system_property_handler -> /pcc/system/property')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    #path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        if method != 'GET':
            raise InvalidMethod('Unsupported method(%s)' % method)
        
        content = get_pcc_property_content_tmpl % json.dumps(pcc_rest_get_property(), ensure_ascii=False, indent = 2)
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_system_property_handler -> successful')
    
    return (code, header, content)

# 列出所有模型信息或者添加模型 -> GET, POST
def pcc_rest_system_models_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_system_models_handler -> /pcc/system/models')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    #path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        if method == 'GET': # list all models
            permmitParams = ['fmt', 'max_results', 'token']
            for i in param_dict:
                if i not in permmitParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % i)
                
            limits = 0
            if 'max_results' in param_dict:
                if not param_dict['max_results'][0].isdigit():
                    raise InvalidValue('max_results should be a digit string')
                limits = int(param_dict['max_results'][0])
            reports = pcc_rest_list_models(limits)
            content = list_models_partial_content_tmpl % json.dumps(reports, indent = 2)
            
        elif method == 'POST': # add model
            requiredParams = ['name', 'version']
            optionalParams = ['port', 'description', 'token']
            
            for i in requiredParams:
                if i not in param_dict:
                    raise MissingQueryString('Parameter <%s> is a must for adding model' % i)
                
            for i in param_dict:
                if i not in requiredParams and i not in optionalParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % i)
                
            # parse model file
            content_type = environ.get('CONTENT_TYPE')
            idx = content_type.find('boundary=')
            if (idx < 0):
                raise MissingFormParams('Model binary file should be upload by form parameter')
            
            boundary = content_type[idx + 9:]
            collections = post_form_content_handler2(environ.get('wsgi.input'), boundary)
            files = []
            if 'files' in collections and collections['files']:
                for filename in collections['files']:
                    PCC_LOG.INFO( 'RECV file:%s' % filename)
                    files.append(filename)
            else:
                raise FileUpload('Parse file content fail')
            
            properties = {}
            properties['name'] = param_dict['name'][0]
            properties['version']  = param_dict['version'][0]
            properties['port'] = int(param_dict.get('port', [0])[0])
            properties['description'] = param_dict.get('description', [''])[0]
            pcc_rest_add_model(properties, files)
            code = '201 CREATED'
            
        else:
            raise InvalidMethod('Unsupported method(%s)' % method)

    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_model_handler -> successful')
        
    return (code, header, content)

# 获取具体模型的信息或者删除、更新 -> GET, DELETE, POST
def pcc_rest_specific_model_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_model_handler -> /pcc/system/models/*')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        (name, version) = rest_util.parse_name_version_from_string(path_nodes[-1])
        if not (name and version):
            raise InvalidUrl("Model's resource id should be formatted as name-a.b.c")
        
        if method == 'GET': # get specific model's information
            permmitParams = ['fmt', 'token']
            for i in param_dict:
                if i not in permmitParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % i)
                
            reports = pcc_rest_get_single_model(name, version)
            if not reports:
                raise ResourceNotFound('No model(%s-%s) found' % (name, version))
            content = list_single_model_partial_content_tmpl % json.dumps(reports[0], indent = 2)
        elif method == 'DELETE': # delete specific model
            permmitParams = ['token']
            for i in param_dict: 
                if i not in permmitParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % i)
                
            pcc_rest_delete_model(name, version)
        elif method == 'POST': # update model
            optionalParams = ['version', 'port', 'description', 'token']
            for i in param_dict: 
                if i not in optionalParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % i)
            
            # parse file if exist
            content_type = environ.get('CONTENT_TYPE')
            idx = content_type.find('boundary=')
            files = []
            if not idx < 0:
                boundary = content_type[idx + 9:]
                collections = post_form_content_handler2(environ.get('wsgi.input'), boundary)
                if 'files' in collections:
                    for filename in collections['files']:
                        PCC_LOG.INFO('RECV file:%s' % filename)
                        files.append(filename)
                else:
                    raise FileUpload('Parse file content fail')
            
            properties = {}
            properties['name'] = name
            properties['version'] = param_dict.get('version', [version])[0]
            properties['port'] = int(param_dict.get('port', [0])[0])
            properties['description'] = param_dict.get('description', [''])[0]
            
            pcc_rest_update_model(name, version, properties, files)
            
            code = '202 ACCEPTED'    
            
        else:
            raise InvalidMethod('Unsupported method(%s)' % method)
        
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_specific_model_handler -> successful')
        
    return (code, header, content)

# 获取模型下所有的模块信息 -> GET
def pcc_rest_specific_model_modules_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_model_modules_handler -> /pcc/system/models/*/modules')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        if method != 'GET':
            raise InvalidMethod('Unsupported method(%s)' % method)
        
        permmitParams = ['fmt', 'token']
        for i in param_dict:
            if i not in permmitParams:
                raise InvalidQueryString('Unknown parameter <%s>' % i)
        
        (name, version) = rest_util.parse_name_version_from_string(path_nodes[-2])
        if not (name and version):
            raise InvalidUrl("Model's resource id should be formatted as name-a.b.c")
        
        info = pcc_rest_get_modules_in_model(name, version)
        content = list_module_partial_content_tmpl % json.dumps(info, ensure_ascii=False, sort_keys=True, indent = 2)
        
        content = json(json.loads(content), ensure_ascii=False, sort_keys=True);

    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_module_handler -> successful')
    
    return (code, header, content)

# 同步服务器时间 -> PUT
def pcc_rest_time_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_time_handler -> /pcc/system/time')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    ########################################################
    raise APINotImplemented('API not implemented yet')
    ########################################################
    
    return (code, header, content)

# 列出所有PCC中心信息 -> GET
def pcc_rest_centers_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_centers_handler -> /pcc/system/centers')

    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    ########################################################
    raise APINotImplemented('API not implemented yet')
    ########################################################
    
    return (code, header, content)

# 列出具体PCC中心信息 -> GET
def pcc_rest_specific_center_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_center_handler -> /pcc/system/centers/*')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    ########################################################
    raise APINotImplemented('API not implemented yet')
    ########################################################
    
    return (code, header, content)

# 列出所有节点信息 -> GET
def pcc_rest_nodes_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_nodes_handler -> /pcc/system/nodes')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    #path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        if method != 'GET':
            raise InvalidMethod('Unsupported method %s' % method)
        
        limits = 0
        if 'max_results' in param_dict:
            if not param_dict['max_results'][0].isdigit():
                raise InvalidValue('max_results should be a digit string')
            limits = int(param_dict['max_results'][0])

        info = pcc_rest_get_nodes_info(param_dict.get('type', ['dynamic'])[0], limits)
        content = get_pcc_nodes_partial_content_tmpl % json.dumps(info, indent = 2)
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_nodes_handler -> successful')
    
    return (code, header, content)

# 列出具体节点信息或者配置节点 -> GET, PUT
def pcc_rest_specific_node_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_node_handler -> /pcc/system/nodes/*')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        if method == 'GET':
            info = pcc_rest_get_single_node_info(path_nodes[-1], param_dict.get('type', ['static'])[0])
            content = get_pcc_single_node_partial_content_tmpl % json.dumps(info, indent = 2)
        elif method == 'PUT': # config nodes
            if 'core_limit' not in param_dict:
                raise InvalidQueryString('Parameter <core_limit> is a must')
            if not param_dict.get('core_limit')[0].isdigit():
                raise InvalidValue('Parameter <core_limit> must be a digit string')
            
            pcc_rest_cfg_node(path_nodes[-1], int(param_dict.get('core_limit')[0]))
            code = '202 ACCEPTED'
                
        else:
            raise InvalidMethod('Unsupported method %s' % method)
        
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_node_handler -> successful')
    
    return (code, header, content)

# 获取签名 -> GET
def pcc_rest_signature_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_signature_handler -> /pcc/signature')
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        if method != 'GET':
            raise InvalidMethod('Unsupported method(%s)' % method)
        
        requiredParams = ['user', 'passwd']
        optionalParams = ['fmt']
        
        for i in requiredParams:
            if i not in param_dict:
                raise MissingQueryString('Parameter <%s> is a must for this resource' % i)
            if not param_dict[i]:
                raise InvalidValue('Unknown parameter <%s> value' % i)
            
        for j in param_dict:
            if j not in requiredParams and j not in optionalParams:
                raise InvalidQueryString('Unknown parameter <%s>' % j)
            
        content = get_signature_content_tmpl % pcc_rest_get_signature(param_dict['user'][0], param_dict['passwd'][0])
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_signature_handler -> successful')
    
    return (code, header, content)

# 查询、注销某个签名 -> GET, DELETE
def pcc_rest_specific_signature_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_signature_handler -> /pcc/signature/*')
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = path_nodes[-1]
        if method == 'GET': # get signature information
            optionalParams = ['fmt']
            
            for j in param_dict:
                if j not in optionalParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % j)
        
            timeout = pcc_rest_get_signature_timeout(signature)
            content = check_signature_valid_content_tmpl % ('true' if timeout > 0 else 'false', timeout)
        elif method == 'DELETE': # unregister signature
            pcc_rest_giveback_signature(signature)
        else:
            raise InvalidMethod('Unsupported method(%s)' % method)
        
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_specific_signature_handler -> successful')
    
    return (code, header, content)

# 列出所有(或部分)作业的信息或者提交作业 -> GET, POST
def pcc_rest_jobs_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_jobs_handler -> /pcc/jobs')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    #path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        if method == 'GET': # query jobs: all jobs, or jobs defined by ids, or by states
            optionalParams = ['id', 'state', 'fmt', 'max_results', 'token']
            for i in param_dict:
                if i not in optionalParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % i)
            
            if 'id' in param_dict and 'state' in param_dict:
                raise InvalidQueryString('Ambiguous parameter <id> and <state>, they should be mutually exclusive')
            
            limits = 0
            if 'max_results' in param_dict:
                if not param_dict['max_results'][0].isdigit():
                    raise InvalidValue('Parameter <max_results> should be a digit string')
                limits = int(param_dict['max_results'][0])
            
            if 'id' in param_dict: # query by ids
                ids = []
                [ids.append(int(i)) for i in param_dict.get('id') if i.isdigit()]
                if not ids:
                    raise InvalidValue('Invalid parameter <id>, each value filed should a digit string')
                
                reports = pcc_rest_query_jobs(ids, limits)
                content = query_jobs_partial_content_tmpl % json.dumps(reports, ensure_ascii=False, indent = 2)
            else: #query by state or query all jobs
                states = param_dict.get('state', ['all'])
                reports = pcc_rest_query_jobs_by_state(states, limits)
                content = query_jobs_partial_content_tmpl % json.dumps(reports, ensure_ascii=False, indent = 2)
            
        elif method == 'POST': # commit job
            optionalParams = ['token', 'fmt']
            for i in param_dict:
                if i not in optionalParams:
                    raise InvalidQueryString('Unknown parameter <%s> for this resource' % i)
                
            request_body_size = int(environ.get('CONTENT_LENGTH', 0))
            if not request_body_size:
                raise MissingContent('Job parameters should be given by json content body at committing job')
            
            request_body = environ['wsgi.input'].read(request_body_size)
            job_params = json.loads(request_body, strict=False)
            requiredFields = ['module', 'module_param', 'input_url', 'output_url']
            for i in requiredFields:
                if i not in job_params:
                    raise MissingContent('Commit job need parameter <%s>' % i)
            
            # optional fields
            if 'task_max_attempts' not in job_params:
                job_params['task_max_attempts'] = -1
                
            out_key = pcc_rest_commit_job(job_params)
            content = commit_job_content_tmpl % out_key
            code = '201 CREATED'
        else:
            raise InvalidMethod('Unsupported method %s' % method)
            
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_job_handler -> successful')
    
    return (code, header, content)

# 查询特定作业的信息或者取消作业 -> GET, DELETE
def pcc_rest_specific_job_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_job_handler -> /pcc/jobs/*')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        key = long(path_nodes[-1])
        if method == 'GET': # get specific job information
            permmisionParams = ['token', 'fmt']
            for i in param_dict:
                if i not in permmisionParams:
                    raise InvalidQueryString('Unknown arameter <%s>' % i)
            report = pcc_rest_query_single_job(key)
            content = query_single_job_partial_content_tmpl % json.dumps(report, ensure_ascii=False, indent = 2)
        elif method == 'DELETE': # delete specific job
            permmisionParams = ['token']
            for i in param_dict:
                if i not in permmisionParams:
                    raise InvalidQueryString('Unknown arameter <%s>' % i)
            pcc_rest_delete_job(id)
        
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_job_handler -> successful')
    
    return (code, header, content)

# 列出作业所有任务的信息 -> GET
def pcc_rest_job_tasks_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_job_tasks_handler -> /pcc/jobs/*/tasks')
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    ########################################################
    raise APINotImplemented('API not implemented yet')
    ########################################################
    
    return (code, header, content)

# 列出作业中特定任务的信息 -> GET
def pcc_rest_specific_job_task_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_job_task_handler -> /pcc/jobs/*/tasks/*')
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    ########################################################
    raise APINotImplemented('API not implemented yet')
    ########################################################
    
    return (code, header, content)

# 列出所有的主干或者创建主干 -> GET, POST
def pcc_rest_trunks_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_trunks_handler -> /pcc/trunks')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    #path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        if method == 'GET': # list all trunks
            limits = 0
            if 'max_results' in param_dict:
                max_results = param_dict['max_results'][0]
                if not max_results.isdigit():
                    raise InvalidQueryString('Parameter <max_results> should be a digit string')
                limits = int(max_results)
                
            infos = pcc_rest_list_trunks(limits)
            content = list_trunk_partial_content_tmpl % json.dumps(infos, ensure_ascii=False)
        elif method == 'POST': # create trunk
            if 'name' not in param_dict:
                    raise MissingQueryString('Parameter <name> is a must for creating trunk')
                
            if not param_dict.get('name', []):
                raise InvalidValue()
            
            pcc_rest_add_trunk(param_dict.get('name')[0])
            code = '201 CREATED'
        else:
            raise InvalidMethod('Unsupported method %s' % method);

    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_trunks_handler -> successful')
    
    return (code, header, content)

# 删除主干或者列出主干下的模块和授权服务器 -> GET, DELETE
def pcc_rest_specific_trunk_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_trunk_handler -> /pcc/trunks/*')
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        if method == 'GET': # get specific trunk
            pass
        elif method == 'DELETE': # delete specific trunk
            pcc_rest_delete_trunk(path_nodes[-1])
        else:
            raise InvalidMethod('Unsupported method %s' % method);
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_specific_trunk_handler -> successful')
    
    return (code, header, content)

# 获取主干下所有的模块信息或者添加模块 -> GET, POST
def pcc_rest_specific_trunk_modules_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_trunk_modules_handler -> /pcc/trunks/*/modules')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        trunk = path_nodes[-2]
        if method == 'GET': # list all modules under specific trunk
            limits = 0
            if 'max_results' in param_dict:
                max_results = param_dict['max_results'][0]
                if not max_results.isdigit():
                    raise InvalidQueryString('Parameter <max_results> should be a digit string')
                limits = int(max_results)
                
            info = pcc_rest_list_modules_in_trunk(trunk, limits)
            content = list_module_partial_content_tmpl % json.dumps(info, ensure_ascii=False, indent = 2)
            
        elif method == 'POST': # add module to this trunk
            requiredParams = ['name', 'version']
            optionalParams = ['description', 'fmt', 'token']
                
            for i in requiredParams:
                if i not in param_dict:
                    raise MissingQueryString('Parameter <%s> is a must for this resource' % i)
                if not param_dict[i]:
                    raise InvalidValue('Parameter %s value invalid' % i)
            
            for j in param_dict:
                if j not in requiredParams and j not in optionalParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % j)
            
            properties = {}
            properties['name'] = param_dict['name'][0]
            properties['version'] = param_dict['version'][0]
            properties['description'] = urllib2.unquote(param_dict.get('description', [''])[0]).decode('utf8').encode('gbk')
            
            # parse file
            content_type = environ.get('CONTENT_TYPE')
            idx = content_type.find('boundary=')
            if (idx < 0):
                raise MissingFormParams('Module binary file should be upload by form parameter')
            
            boundary = content_type[idx + 9:]
            collections = post_form_content_handler2(environ.get('wsgi.input'), boundary)
            files = []
            if 'files' in collections:
                for filename in collections['files']:
                    PCC_LOG.INFO('RECV file:%s' % filename)
                    files.append(filename)
            else:
                raise FileUpload('Parse file content fail')
            
            pcc_rest_add_module(trunk, properties, files)
            code = '201 CREATED'
        else:
            raise InvalidMethod('Unsupported method %s' % method);
                
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_specific_trunk_modules_handler -> successful')
    
    return (code, header, content)

# 获取特定模块的信息或者删除特定模块 -> GET, DELETE
def pcc_rest_specific_trunk_specific_module_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_specific_trunk_specific_module_handler -> /pcc/trunks/*/modules/*')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        (name, version) = rest_util.parse_name_version_from_string(path_nodes[-1])
        trunk = path_nodes[-3]
        
        if not (name and version):
            raise InvalidUrl('No module(%s-%s) found' % (name, version))
        
        if method == 'GET': # get specific module information
            optionalParams = ['token', 'fmt']
            for i in param_dict:
                if i not in optionalParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % i)
                
            info = pcc_rest_get_module_info(name, version, trunk)
            content = get_module_info_partial_content_tmpl % json.dumps(info, ensure_ascii=False, indent = 2)
        elif method == 'DELETE': # delete specific module
            optionalParams = ['token']
            for i in param_dict:
                if i not in optionalParams:
                    raise InvalidQueryString('Unknown parameter <%s>' % i)
                
            pcc_rest_delete_module(name, version, trunk)
        else:
            raise InvalidMethod('Unsupported method %s' % method);

    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_specific_trunk_specific_module_handler -> successful')
    
    return (code, header, content)

# 添加、删除权限服务器或者获取权限服务器信息 -> GET, POST, DELETE
def pcc_rest_auth_center_handler(environ):
    PCC_LOG.DEBUG( 'pcc_rest_auth_center_handler -> /pcc/trunks/*/auth')
    
    code = '200 OK'
    header = [('Content-type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    '''
    # 通过application/binary数据来上传文件
    request_body_size = int(environ.get('CONTENT_LENGTH', 0))
    request_body = environ['wsgi.input'].read(request_body_size)
    f = open('test.txt', 'ab')
    f.write(request_body)
    f.close
    d = urlparse.parse_qsl(request_body)
    '''

    try:
        signature = param_dict.get('token', [])
        if not signature:
            raise NeedSignature('Parameter <token> is needed')
        
        if not pcc_rest_valid_signature(signature[0]):
            raise NoAuthority('Signature <%s> is expired, please apply another' % signature)
        
        if method == 'GET': # get authority server's information
            report = pcc_rest_list_auth_center(path_nodes[-2])
            content = list_auth_center_partial_content_tmpl % json.dumps(report, indent = 2)
        elif method == 'DELETE': # delete authority server
            pcc_rest_delete_auth_center_by_trunk(path_nodes[-2])
        elif method == 'POST': # add authority server
            requiredParams = ['name', 'version']
            for param in requiredParams:
                if param not in param_dict:
                    raise MissingQueryString('Parameter <%s> is a must for POST method on this resource' % param)
                if not param_dict[param][0]:
                    raise InvalidValue('No value for parameter <%s>' % param)
                
            # parse file from form content
            content_type = environ.get('CONTENT_TYPE')
            idx = content_type.find('boundary=')
            if (idx < 0):
                raise MissingFormParams('GPL formatted file should be uploaded by form parameter for add authority server')
            
            boundary = content_type[idx + 9:]
            collections = post_form_content_handler2(environ.get('wsgi.input'), boundary)
            if 'files' in collections:
                for filename in collections['files']:
                    PCC_LOG.INFO('RECV file:%s' % filename)
                    
            pcc_rest_add_auth_center(path_nodes[-2], param_dict['name'][0], param_dict['version'][0], collections['files'])
            code = '201 CREATED'
        else:
            raise InvalidMethod('Unsupported method %s' % method);
        
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        PCC_LOG.INFO('pcc_rest_auth_center_handler -> successful')
    
    return (code, header, content)

    
