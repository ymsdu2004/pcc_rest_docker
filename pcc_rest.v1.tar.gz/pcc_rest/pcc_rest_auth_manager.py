#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_auth_manager.py
# 2014-10-24
#

import sqlite3
import uuid
import time
from pcc_rest_concrete_exception import *
from pcc_rest_logger import PCC_LOG
#from rest_util import singleton
from rest_util import Singleton

#@singleton
class PccAuthManager(Singleton):
    
    '''
    Simple Authority Manager for pcc rest api access 
    '''
    
    signature_defult_timeout = 72 * 3600 # 3 days
    db_file_name = 'pcc_rest.db'
    sql_create_user_table = '''CREATE TABLE IF NOT EXISTS user
    (name TEXT PRIMARY KEY, password TEXT NOT NULL, role INTEGER NOT NULL)'''
    
    sql_create_signature_table = '''CREATE TABLE IF NOT EXISTS signature
    (token TEXT PRIMARY KEY, user TEXT NOT NULL, timeout INTEGER NOT NULL)'''
    
    sql_insert_user = """INSERT INTO user VALUES ('%s', '%s', %d)"""
    sql_delete_user = """DELETE FROM user WHERE name = '%s'"""
    sql_insert_signature = """INSERT INTO signature VALUES('%s', '%s', %d)"""
    sql_get_signatue_timeout = """SELECT timeout FROM signature WHERE token = '%s'"""
    sql_delete_signature = """DELETE FROM signature WHERE token = '%s'"""
    
    def __init__(self):
            
        conn = sqlite3.connect(PccAuthManager.db_file_name)
        c = conn.cursor()
        c.execute(PccAuthManager.sql_create_user_table)
        c.execute(PccAuthManager.sql_create_signature_table)
        c.execute("SELECT * FROM user")
        
        # default user
        for row in c:
            if row[0] == 'netposa':
                break
        else:
            c.execute(PccAuthManager.sql_insert_user % ('netposa', '123456', 0))
            
        conn.commit()
        c.close()
        conn.close()
        
    def _generate_signature(self):
        return (uuid.uuid1(), int(time.time()) + PccAuthManager.signature_defult_timeout)
        
    def addUser(self, user, passwd):
        conn = sqlite3.connect(PccAuthManager.db_file_name)
        c = conn.cursor()
        c.execute("SELECT * FROM user")
        exist = False
        for row in c:
            if row[0] == user:
                exist = True
                break
        else:
            c.execute(PccAuthManager.sql_insert_user % (user, passwd, 1))
        
        conn.commit()
        c.close()
        conn.close()
        
        if exist:
            raise UserAlreadyExist('User %s already exist, please try another one' % user)
        
    def delUser(self, user):
        if user == 'netposa':
            raise OperationDenied('Internal user netposa can not be deleted')
        
        conn = sqlite3.connect(PccAuthManager.db_file_name)
        c = conn.cursor()
        c.execute(PccAuthManager.sql_delete_user % user)
        conn.commit()
        c.close()
        conn.close()
    
    def applySignature(self, user, passwd):
        conn = sqlite3.connect(PccAuthManager.db_file_name)
        c = conn.cursor()
        c.execute("SELECT * FROM user")    
        # default user
        
        
        state = 0
        for row in c:
            if row[0] == user:
                if row[1] != passwd:
                    state = 1 # wrong password
                break
        else:
            state = 2 # no this user
            
        if state == 0:
            signature, timeout = self._generate_signature()
            c.execute(PccAuthManager.sql_insert_signature % (signature, user, timeout))
            timeout = timeout - int(time.time())
            
        conn.commit()
        c.close()
        conn.close()
        
        if state == 1:
            raise InvalidPasswd('Invalid password <%s> for user %s' % (passwd, user))
        elif state == 2:
            raise InvalidUser('Unauthorized user <%s>' % user)
        
        return (signature, timeout)
    
    def givebackSignature(self, signature):
        conn = sqlite3.connect(PccAuthManager.db_file_name)
        c = conn.cursor()
        c.execute(PccAuthManager.sql_delete_signature % signature)
        conn.commit()
        c.close()
        conn.close()
     
    def getSignatureTimeout(self, signature):
        conn = sqlite3.connect(PccAuthManager.db_file_name)
        c = conn.cursor()
        c.execute(PccAuthManager.sql_get_signatue_timeout % signature)
        timeout = -1
        row = c.fetchone()
        if row:
            timeout = int(row[0])
            diff = timeout - int(time.time())
            timeout = diff
            if diff < 0:
                print 'signature %s is timeout, remove it' % signature
                c.execute(PccAuthManager.sql_delete_signature % signature)
                timeout = -1
             
        conn.commit()
        c.close()
        conn.close()
        
        return timeout
    