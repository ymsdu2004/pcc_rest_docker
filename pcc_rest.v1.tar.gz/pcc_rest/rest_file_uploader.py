#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# rest_uploader.py
# 2014-10-24
#

import urllib2
from pcc_rest_logger import PCC_LOG
####################################################
# REC1867
#
#
# {'files': {'file1': data, 'file2': data, ...}, 'fields': {'field1': value, 'field2': value, ...}}
def post_form_content_handler(input_string, boundary):
    
    # 'disposition', 'type', 'data', 'blank'
    state  = ''
    datas = {'files': {}, 'fields': {}}
    data = ''
    name = ''
    filename = ''
    for line in input_string:
        if line.strip().endswith(boundary+'--'):
            if filename:
                datas['files'][filename] = data   
            elif name:
                datas['fields'][name] = data
            break
        elif line.strip().endswith(boundary): # a new record
            if filename:
                datas['files'][filename] = data   
            elif name:
                datas['fields'][name] = data
            filename = ''
            name = ''
            data = ''
            state = 'disposition'
        elif state == 'disposition':
            item_dict = {}
            items = line.split(';')
            for i in items:
                k_v = i.split('=')
                if len(k_v) >= 2:
                    item_dict[k_v[0].strip().strip('"')] = k_v[1].strip().strip('"')
            if 'name' in item_dict: # is a must, you should assert here
                name = item_dict.get('name')
                state = 'blank'
            if 'filename' in item_dict:
                filename = item_dict.get('filename')
                state = 'type'
        elif state == 'type':
            state = 'blank'
        elif state == 'data':
            data += line
        elif state == 'blank':
            state = 'data'
        else:
            # format error
            PCC_LOG.ERROR('form context error')
            break
            
    return datas

# {'files': ['file1', 'file2', ... ], 'fields': {'field1': value, 'field2': value, ...}}
def post_form_content_handler2(input_string, boundary):
    
    # 'disposition', 'type', 'data', 'blank'
    state  = ''
    datas = {'files': [], 'fields': {}}
    data = ''
    name = ''
    filename = ''
    f = None
    for line in input_string:
        if line.strip().endswith(boundary+'--'):
            if filename:
                datas['files'].append(filename)   
            elif name:
                datas['fields'][name] = data
            break
        elif line.strip().endswith(boundary): # a new record
            if filename:
                datas['files'].append(filename)   
            elif name:
                datas['fields'][name] = data
            filename = ''
            name = ''
            data = ''
            state = 'disposition'
        elif state == 'disposition':
            item_dict = {}
            items = line.split(';')
            for i in items:
                k_v = i.split('=')
                if len(k_v) >= 2:
                    item_dict[k_v[0].strip().strip('"')] = k_v[1].strip().strip('"')
            if 'name' in item_dict: # is a must, you should assert here
                name = item_dict.get('name')
                state = 'blank'
            if 'filename' in item_dict:
                filename = urllib2.unquote(item_dict.get('filename')).decode('utf8')
                f = open(filename, 'ab')
                state = 'type'
        elif state == 'type':
            state = 'blank'
        elif state == 'data':
            if f:
                f.write(line)
            else:
                data = line.strip()
        elif state == 'blank':
            state = 'data'
        else:
            # format error
            PCC_LOG.ERROR( 'form context error')
            break
        
    if f:
        f.close()
            
    return datas

class FileUploader(object):
    def __init__(self):
        pass