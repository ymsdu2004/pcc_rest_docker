#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_logger.py
# 2014-11-11
#

import logging
from logging.handlers import RotatingFileHandler

class PccRestLogger:
    '''
    '''
    
    def __init__(self, name):
        logging.basicConfig(level=logging.DEBUG,
                format='%(asctime)s %(filename)s[line:%(lineno)d] [%(levelname)s] %(message)s',
                #datefmt='%a, %d %b %Y %H:%M:%S',
                filename='pcc_rest.log',
                filemode='a')
        self.logger = logging.getLogger(name)
        console = logging.StreamHandler()
        console.setLevel(logging.INFO)
        console_fmt = logging.Formatter('%(message)s')
        console.setFormatter(console_fmt)
        
        #handle = RotatingFileHandler('pcc_rest.log', mode = 'a',  maxBytes = 1024)
        #formatter2 = "%(asctime)s %(levelname)-8s[%(filename)s:%(lineno)d(%(funcName)s)] %(message)s"
        #handle.setLevel(logging.DEBUG)
        #handle.setFormatter(formatter2)
        #self.logger.addHandler(handle)
        self.logger.addHandler(console)
        
    def DEBUG(self, msg):
        self.logger.debug(msg)
        
    def INFO(self, msg):
        self.logger.info(msg)
        
    def WARNING(self, msg):
        self.logger.warning(msg)
        
    def ERROR(self, msg):
        self.logger.error(msg)
        
    def CRITICAL(self, msg):
        self.logger.critical(msg)
        
PCC_LOG = PccRestLogger('pcc_rest')