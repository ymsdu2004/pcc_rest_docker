#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_test_data_generator.py
# 2014-10-24
#

test_pcc_node_static_data = \
{
     "name": "127.0.0.1-9011",
     "cpu_type": 2,
     "cpu_freq": 3213,
     "cpu_processors": 8,
     "total_memory_bytes": 1873423,
     "network_bandwidth": 239011,
     "os_type": 1,
     "os_detail": "windows7-32bits",
     "execute_bits": 32,
     "is_online": True
}

test_pcc_node_dynamic_data = \
{
    'name': '127.0.0.1-9011',
    'cpu_usage': 56,
    'memory_usage': 19,
    'network_usage': 8,
    'core_limits': 12,
    'is_enable': False
}

test_pcc_node_all_data = \
{
    "name": "127.0.0.1-9011",
    "static":
    {
         "cpu_type": 2,
         "cpu_freq": 3213,
         "cpu_processors": 8,
         "total_memory_bytes": 1873423,
         "network_bandwidth": 239011,
         "os_type": 1,
         "os_detail": "windows7-32bits",
         "execute_bits": 32,
         "is_online": True
     },
     "dynamic":
     {
        'cpu_usage': 56,
        'memory_usage': 19,
        'network_usage': 8,
        'core_limits': 12,
        'is_enable': False
    }
}

test_query_jobs_data = \
{
    "key": 12,
    "report":
    {
        "info":
        {
            "module_key": 123,
            "data_input_url": "PFS://10.1.17.115.9000/admin/admin:/videofile/a.avi",
            "data_output_url": "DDB://10.1.5.13.3306/root/NULL/pvd]",
            "priority": 2,
            "task_timeout": 20000,
            "max_attempts": 100,
            "failed_task_percent": 10,
            "name": "Test_1",
            "program_param": "xxxxxxxxxxxxxxxxx"
        },
        "state": 2,
        "progress": 90,
        "cost_msels": 14231,
        "processed_msels": 1432,
        "commit_time": 14214531,
        "error_code": -10035,
        "error_description": "invalid parameter"    
    }
}

test_list_models_data = \
{
    "key": 123,
    "property":
    {
        "name": "Grid-1.2.0",
        "version": "1.2.0",
        "description": "JobCenter",
        "add_time": 1416231113,
        "ip": "192.168.12.17",
        "port": 9021
    }
}

test_list_modules_data = \
{
    "key": 782,
    "model_key": 121,
    "property":
    {
        "name": "Netposa-SVAC",
        "version": "1.2.1",
        "pattern": 34,
        "file_type": 2,
        "type": 12,
        "latency": 3,
        "description": "xxx",
        "platform": 2,
        "add_time": 14287677128,
        "size": 23412
    }
}

test_list_pcc_auth_center_data = \
{
    "name": "127.0.0.1-10",
    "version": "1.2.3"
}


def test_get_pcc_single_node_static_info(node):
    return test_pcc_node_static_data

def test_get_pcc_single_node_dynamic_info(node):
    return test_pcc_node_dynamic_data

def test_get_pcc_single_node_all_info(node):
    return test_pcc_node_all_data

def test_get_pcc_nodes_static_info(node):
    data = []
    [data.append(test_pcc_node_static_data) for i in range(5)]
    return data

def test_get_pcc_nodes_dynamic_info(node):
    data = []
    [data.append(test_pcc_node_dynamic_data) for i in range(5)]
    return data

def test_get_pcc_nodes_all_info(node):
    data = []
    [data.append(test_pcc_node_all_data) for i in range(5)]
    return data
    

def test_query_jobs(jobs):
    reports = []
    [reports.append(test_query_jobs_data) for i in jobs]
    return reports

def test_query_single_job(job):
    return test_query_jobs_data

def test_query_jobs_by_state(states):
    reports = []
    [reports.append(test_query_jobs_data) for i in states]
    return reports

def test_list_models():
    reports = []
    [reports.append(test_list_models_data) for i in range(5)]
    return reports

def test_list_modules_in_trunk(trunk):
    data = []
    [data.append(test_list_modules_data) for i in range(5)]
    return data

def test_get_module_info(name, version):
    return test_list_modules_data

def test_pcc_list_auth_center(trunk):
    reports = []
    [reports.append(test_list_pcc_auth_center_data) for i in range(5)]
    return reports

def test_list_trunks():
    reports = []
    [reports.append('trunk_%d' % i) for i in range(5)]