#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_concrete_api.py
# 2014-10-24
#
import rest_util
from pcc_rest_auth_manager import PccAuthManager
from pcc_test_data_generator import *
from pcc_rest_concrete_exception import *
from pcc_proxy import PCCProxy

def pcc_rest_get_signature(user, passwd):
    return PccAuthManager().applySignature(user, passwd)

def pcc_rest_get_signature_timeout(signature):
    return PccAuthManager().getSignatureTimeout(signature)

def pcc_rest_giveback_signature(signature):
    return PccAuthManager().givebackSignature(signature)

def pcc_rest_valid_signature(signature):
    timeout = pcc_rest_get_signature_timeout(signature)
    return timeout > 0
    

def pcc_rest_get_property():
    ##################### TEST ###################
    #return '2.0.1'
    return  PCCProxy().get_property()

pcc_rest_node_info_type = ['static', 'dynamic', 'all']

def pcc_rest_get_nodes_info(info_type, limits):
    if info_type not in pcc_rest_node_info_type:
        raise ValueOverRange('unknown type=%s, only static, dynamic, all allowed' % info_type)
    
    ####################### TEST #########################
    result = []
    
    if info_type == 'static':
        #return test_get_pcc_nodes_static_info(info_type)
        result =  PCCProxy().list_nodes_static_info()
    elif info_type == 'dynamic':
        #return test_get_pcc_nodes_dynamic_info(info_type)
        result =  PCCProxy().list_nodes_dynamic_info()
    else:
        #return test_get_pcc_nodes_all_info(info_type)
        result =  PCCProxy().list_nodes_all_info()
    ######################################################
    
    length = len(result)
    return result[0: limits if limits > 0 and limits < length else length]
    
def pcc_rest_get_single_node_info(node, info_type):
    if info_type not in pcc_rest_node_info_type:
        raise ValueOverRange('unknown type=%s, only static, dynamic, all allowed' % info_type)
    
    ####################### TEST #########################
    if info_type == 'static':
        #return test_get_pcc_single_node_static_info(node)
        return  PCCProxy().get_node_static_info(node)
    elif info_type == 'dynamic':
        #return test_get_pcc_single_node_dynamic_info(node)
        return  PCCProxy().get_node_dynamic_info(node)
    
    #return test_get_pcc_single_node_all_info(node)
    return  PCCProxy().get_node_all_info(node)
    ######################################################
    
def pcc_rest_cfg_node(node, core_limit):
    return  PCCProxy().config_node(node, core_limit)

def pcc_rest_query_jobs(jobs, limits):
    ###################### TEST #########################
    #return test_query_jobs(jobs)
    ######################################################
    result =  PCCProxy().query_jobs_by_id(jobs) 
    length = len(result)
    return result[0: limits if limits > 0 and limits < length else length]
    
pcc_rest_states = \
{
    'all':      -1,
    'waiting':  0x01,
    'running':  0x02,
    'ok':       0x04,
    'failed':   0x08,
}
def pcc_rest_query_jobs_by_state(states, limits):
    for i in range(len(states)):
        states[i] = states[i].strip().lower()
        if  states[i]not in pcc_rest_states:
            raise ValueOverRange("'%s' is unknown state, only <all, waiting, running, ok, failed> allowed" % i)
        
    ###################### TEST ##########################
    # return test_query_jobs_by_state(_states)
    ######################################################
    
    _states = 0
    for s in states:
        if pcc_rest_states[s] == -1:
            _states = -1
            break
        
        _states |= pcc_rest_states[s]
        
    result =  PCCProxy().query_jobs_by_state(_states)
    length = len(result)
    return result[0: limits if limits > 0 and limits < length else length]
    
def pcc_rest_query_single_job(job):
    ###################### TEST ##########################
    #return test_query_single_job(job)
    ######################################################
    job_report =  PCCProxy().query_jobs_by_id([job,])
    if not job_report:
        raise PCCExecuteFail('No job %d' % job)
    
    return job_report[0]
    
def pcc_rest_delete_job(job_key):
    return   PCCProxy().cancel_job(job_key)

def pcc_rest_add_auth_center(trunk, name, version, filenames):
    ###################### TEST #########################
    print 'Upload auth-center: trunk=%s, name=%s, version=%s' % (trunk, name, version)
    for f in filenames:
        print 'Upload file: %s ...' % f
    ######################################################
    return  PCCProxy().add_auth_center(trunk, name, version, filenames)
    
def pcc_rest_delete_auth_center_by_trunk(trunk):
    ###################### TEST #########################
    #raise OperationDenied("Operation denied for deleting trunk")
    ######################################################
    return  PCCProxy().remove_auth_center_ex(trunk)
    
def pcc_rest_delete_auth_center(trunk, name, version):
    ###################### TEST #########################
    #raise OperationDenied("Operation denied for deleting trunk")
    ######################################################
    return  PCCProxy().remove_auth_center(trunk, name, version)
    
def pcc_rest_list_auth_center(trunk):
    ###################### TEST #########################
    #return test_pcc_list_auth_center(trunk)
    ######################################################
    return  PCCProxy().list_auth_center(trunk)
    
def pcc_rest_list_modules_in_trunk(trunk, limits):
    ###################### TEST #########################
    #return test_list_modules_in_trunk(trunk)
    ######################################################
    result =  PCCProxy().list_modules(trunk)
    length = len(result)
    return result[0: limits if limits > 0 and limits < length else length]

def pcc_rest_get_modules_in_model(name, version):
    raise APINotImplemented('API not implemented yet')
    
def pcc_rest_get_module_info(name, version, trunk):
    ###################### TEST #########################
    #return test_get_module_info(name, version)
    ######################################################
    result =  PCCProxy().get_module_by_name(trunk, name, version)
    if not result:
        raise InvalidUrl('No module (%s-%s) found under trunk %s' % (name, version, trunk))
    
    return result[0]
    
    
def pcc_rest_delete_module(name, version, trunk):
    ###################### TEST #########################
    #raise OperationDenied("Operation denied for deleting module")
    ######################################################
    result =  PCCProxy().get_model_by_name(trunk, name, version)
    if not result:
        raise InvalidUrl('No module (%s-%s) found under trunk %s' % (name, version, trunk))
    
    module_key = result[0].get('key', -1)
    return  PCCProxy().remove_module(trunk, module_key)
        
def pcc_rest_delete_trunk(name):
    ###################### TEST #########################
    #raise OperationDenied("Operation denied for deleting trunk")
    ######################################################
    return  PCCProxy().remove_trunk(name)
    
def pcc_rest_list_trunks(limits = 0):
    ###################### TEST #########################
    #return test_list_trunks()
    ######################################################
    result =  PCCProxy().list_trunk()
    length = len(result)
    return result[0: limits if limits > 0 and limits < length else length]
    
def pcc_rest_add_trunk(name):
    ###################### TEST #########################
    #raise OperationDenied("Operation denied for adding trunk")
    ######################################################
    return  PCCProxy().create_trunk(name)
    
def pcc_rest_delete_model(name, version):
    ###################### TEST #########################
    #raise OperationDenied("Operation denied for deleting model")
    ######################################################
    info =  PCCProxy().get_model_by_name(name, version)
    if not info:
        raise ResourceNotFound('No mode (%s-%s) found' % (name, version))
    
    model_key = info[0].get('key', -1)
    return  PCCProxy().remove_model(model_key)
    
def pcc_rest_list_models(limits):
    ###################### TEST #########################
    #return test_list_models()
    ######################################################
    result =  PCCProxy().list_models()
    length = len(result)
    return result[0: limits if limits > 0 and limits < length else length]

def pcc_rest_get_single_model(name, version):
    return  PCCProxy().get_model_by_name(name, version)
    
def pcc_rest_set_model_port(name, version, port):
    ###################### TEST #########################
    #raise OperationDenied("Operation denied for setting model port")
    ######################################################
    return  PCCProxy().set_model_port(name, version, port)
    
def pcc_rest_add_model(properties, files):
    #print 'Add model: name = %s, version = %s, ip = %s, port = %d, description = %s, time = %d, files = %s'\
    # % (name, version, ip, port, desc, time, files)
    
    return  PCCProxy().add_model(properties, files)

def pcc_rest_update_model(name, version, properties, files):
    info =  PCCProxy().get_model_by_name(name, version)
    if not info:
        raise ResourceNotFound('No mode (%s-%s) found' % (name, version))
    
    model_key = info[0].get('key', -1)
    return  PCCProxy().update_model(model_key, properties, files)

def pcc_rest_commit_job(job_params):
    print 'Commit job:', job_params
    ############################ TEST #####################
    #return 1238
    #######################################################
    module_uri_nodes = rest_util.url_path_split(job_params['module'])
    if len(module_uri_nodes) < 2:
        raise InvalidContent('Filed <module> should give be module uri string')
    
    idx = module_uri_nodes[-1].rfind('-')
    if idx == -1 or idx == 0 or idx == len(module_uri_nodes[-1])-1:
        raise InvalidContent('Filed <module> not find version string')
    
    moduel_info =  PCCProxy().get_module_by_name(module_uri_nodes[-2], module_uri_nodes[-1][0:idx], module_uri_nodes[-1][idx+1:])
    if 'key' not in moduel_info[0]:
        raise InvalidContent('Module <%s> not found' % job_params['module'])
    return  PCCProxy().commit_job(int(moduel_info[0]['key']),
                                                      job_params['input_url'],
                                                      job_params['output_url'],
                                                      int(job_params['task_max_attempts']),
                                                      job_params['module_param'])
    
def pcc_rest_add_module(trunk, properties, files):
    return  PCCProxy().add_module(trunk, properties, files)