#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# base_exception.py
# 2014-10-24
#

class PccBaseException(Exception):
    def __init__(self, code, message, status = '200 OK'):
        Exception.__init__(self)
        self.code = code
        self.message = message
        self.status = status
        
    def __str__(self):
        return self.message