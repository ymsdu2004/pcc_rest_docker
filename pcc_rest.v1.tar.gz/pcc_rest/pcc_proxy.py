#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_proxy.py
# 2014-10-24
#

import os
import urllib2
import pcc_rest_exception
import pcc_rest_concrete_exception
import PCCUserPyWrapper as pcc_user
import pcc_rest_request_exception
from pcc_rest_logger import PCC_LOG
from rest_util import Singleton

class PCCProxy(Singleton):
    '''
    Simple pcc connector, with which we access the service it's supplied
    '''
    
    PCC_OK = 0
    
    def _TransException(self, e):
        return pcc_rest_request_exception.InternalFailure(e[0], e[1])
    
    def __init__(self):
        pass
        
    def prepare(self, ip, port):
        '''
        Initialize before use
        @ip[str]: ip address, format as 'a.b.c.d'
        @port[int]: service network port
        '''
        self.ip = ip
        self.port = port
        self.initialized = False
        
        try:
            pcc_user.Init()
            self.initialized = True
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.Init exception:%s' % e)
            self.initialized = False
            raise self._TransException(e)
        
    def open(self):
        '''
        open an connection to pcc, it's a must before you can do any operation
        '''
        if not self.initialized:
            raise pcc_rest_concrete_exception.ConnUninitialized('Internal error, PCC-SDK uninitialized yet')
        
        try:
            pcc_user.SetServeIPP('%s.%d' % (self.ip, self.port))
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.SetServeIPP exception: %s' % e)
            raise self._TransException(e)
    
    def close(self):
        '''
        close the connection to pcc
        '''
        pass
    
    def login(self, user, password):
        '''
        login pcc by user name and password to get the access authority
        @user[str]: user name
        @password[str]: the password for specific user
        '''
        pass
    
    def logout(self):
        '''
        logout to pcc
        '''
        pass
    
    def list_trunk(self, limits = 0):
        '''
        list all trunks in pcc
        '''
        result = []
        
        try:
            pcc_user.ListTrunk(result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListTrunk exception:%s' % e)
            raise self._TransException(e)
        
        return result
    
    def list_models(self):
        '''
        list all models's information in pcc
        '''
        result = []
        try:
            pcc_user.ListModels(result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListModels exception:%s' % e)
            raise self._TransException(e)
        
        return result
    
    def list_modules(self, trunk):
        '''
        list all modules under specific trunk
        @trunk[string]: trunk name
        '''
        result = []
        try:
            pcc_user.ListModules(urllib2.unquote(trunk).decode('utf8').encode('gbk'), result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListModules exception:%s' % e)
            raise self._TransException(e)
        
        return result
    
    def list_modules_ex(self, model, version):
        '''
        list all modules under specific model specified by model name and version
        @model[str]: model's name
        @version[str]: model's version, format as 'a.b.c' 
        '''
        result = []
        try:
            pcc_user.ListModulesEx(urllib2.unquote(model).decode('utf8').encode('gbk'), version, result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListModulesEx exception:%s' % e)
            raise self._TransException(e)
        
        return result
    
    def query_jobs_by_state(self, states):
        '''
        query jobs by job state
        '''
        result = []
        try:
            pcc_user.QueryJobsByState(states, result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.QueryJobsByState exception - %s' % e)
            raise self._TransException(e)
        
        return result
    
    def query_jobs_by_id(self, ids):
        '''
        query jobs by job keys
        '''
        
        result = []
        try:
            pcc_user.QueryJobsByID(ids, result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.QueryJobsByID exception - %s' % e)
            raise self._TransException(e)
        
        return result
    
    def commit_job(self, module_key, input_data_url, output_data_url, max_attempts, module_param):
        '''
        commit a job
        '''
        job_key = -1
        try:
            job_key = pcc_user.CommitJob(module_key, input_data_url.encode('gbk'), output_data_url.encode('gbk'),
                                           max_attempts, module_param.encode('gbk'))
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.CommitJob exception - %s' % e)
            raise self._TransException(e)
        
        return job_key
    
    def cancel_job(self, job):
        '''
        cancel a job
        @job[int]: job key
        '''
        
        try:
            pcc_user.CancelJob(job)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.CancelJob exception - %s' % e)
            raise self._TransException(e)
        
    def list_nodes_static_info(self):
        
        result = []
        try:
            pcc_user.ListNodes(result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListNodes exception - %s' % e)
            raise self._TransException(e)
        
        return result
    
    def list_nodes_dynamic_info(self):
        
        result = []
        try:
            pcc_user.ListNodesDynamic(result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListNodesDynamic exception - %s' % e)
            raise self._TransException(e)
        
        return result
    
    def list_nodes_all_info(self):
        
        result = []
        try:
            pcc_user.ListNodesInfo(result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListNodesInfo exception - %s' % e)
            raise self._TransException(e)
        
        return result
    
    def get_node_static_info(self, node):
        statics = {}
        try:
            pcc_user.GetNodeStaicsInfo(node, statics)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.GetNodeStaicsInfo exception - %s' % e)
            raise self._TransException(e)
        
        return statics
    
    def get_node_dynamic_info(self, node):
        dynamics = {}
        try:
            pcc_user.GetNodeDynamicContext(node, dynamics)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.GetNodeDynamicContext exception - %s' % e)
            raise self._TransException(e)
        
        return dynamics
    
    def get_node_all_info(self, node):
        info = {}
        try:
            pcc_user.GetNodeInfo(node, info)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.GetNodeInfo exception - %s' % e)
            raise self._TransException(e)
        
        return info
    
    def list_auth_center(self, trunk):
        
        result = []
        try:
            pcc_user.ListAuthCenter(urllib2.unquote(trunk).decode('utf8').encode('gbk'), result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListAuthCenter exception - %s' % e)
            raise self._TransException(e)
        
        return result
    
    def create_trunk(self, trunk):
        
        try:
            pcc_user.CreateTrunk(urllib2.unquote(trunk).decode('utf8').encode('gbk'))  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.CreateTrunk exception - %s' % e)
            raise self._TransException(e)
        return 0
    
    def remove_trunk(self, trunk):
        try:
            pcc_user.RemoveTrunk(urllib2.unquote(trunk).decode('utf8').encode('gbk'))  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.RemoveTrunk exception - %s' % e)
            raise self._TransException(e)
        
        return 0
    
    def add_module(self, trunk, properties, files):
        try:
            pcc_user.AddModule(urllib2.unquote(trunk).decode('utf8').encode('gbk'), properties, files)  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.AddModule exception - %s' % e)
            raise self._TransException(e)
        finally:
            for i in files:
                os.remove(i)
        
        return 0
    
    def remove_module(self, trunk, key):
        '''
        remove specific module under trunk
        @trunk[string]: trunk name
        @key[long]: module's key
        '''
        try:
            pcc_user.RemoveModule(urllib2.unquote(trunk).decode('utf8').encode('gbk'), key)  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.RemoveModule exception - %s' % e)
            raise self._TransException(e)
        
        return 0
    
    def remove_module_ex(self, key):
        '''
        remove a module specified by the module key
        @key[long]: module's key 
        '''
        try:
            pcc_user.RemoveModuleEx(key)  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.RemoveModuleEx exception - %s' % e)
            raise self._TransException(e)
        
        return 0
    
    def remove_model(self, model_key):
        try:
            pcc_user.DelModel(model_key)  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.DelModel exception - %s' % e)
            raise self._TransException(e)
        
        return 0
    
    def add_model(self, properties, files):
        '''
        add a model
        @properties[dict]: model's information
        @files[list]: model's files
        '''
        try:
            pcc_user.AddModel(properties, files)  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.AddModel exception - %s' % e)
            raise self._TransException(e)
        finally:
            for i in files:
                os.remove(i)
        
        return 0
    
    def update_model(self, key, properties, files):
        try:
            pcc_user.UpdateModel(key, properties, files)  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.UpdateModel exception - %s' % e)
            raise self._TransException(e)
        finally:
            for i in files:
                os.remove(i)
        
        return 0
        
    
    def add_auth_center(self, trunk, name, version, files):
        '''
        add authority center
        @trunk[string]: trunk name
        @name[string]: authority center's name
        @version[string]: authority center's version, format as 'a.b.c'
        @files[list]: authority center's files
        '''
        try:
            
            for i in range(len(files)):
                files[i] = files[i].encode('gbk')
                
            pcc_user.AddAuthCenter(urllib2.unquote(trunk).decode('utf8').encode('gbk'), 
                                   urllib2.unquote(name).decode('utf8').encode('gbk'), version, files)  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.AddAuthCenter exception - %s' % e)
            raise self._TransException(e)
        finally:
            for i in files:
                os.remove(i)
        
        return 0
    
    def remove_auth_center(self, trunk, name, version):
        try:
            pcc_user.RemoveAuthCenter(urllib2.unquote(trunk).decode('utf8').encode('gbk'), 
                                   urllib2.unquote(name).decode('utf8').encode('gbk'), version)  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.RemoveAuthCenter exception - %s' % e)
            raise self._TransException(e)
        
        return 0
    
    def remove_auth_center_ex(self, trunk):
        try:
            pcc_user.RemoveAuthCenterEx(urllib2.unquote(trunk).decode('utf8').encode('gbk'))  
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.RemoveAuthCenterEx exception - %s' % e)
            raise self._TransException(e)
        
        return 0
    
    def get_property(self):
        property = {}
        try:
            pcc_user.GetProperty(property)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.GetProperty exception - %s' % e)
            raise self._TransException(e)
        
        return property
    
    def set_model_port(self, name, version, port):
        try:
            pcc_user.ConfigModel(urllib2.unquote(name).decode('utf8').encode('gbk'), version, port)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ConfigModel exception - %s' % e)
            raise self._TransException(e)
        
        return 0
    
    def config_node(self, node, core_limit):
        try:
            pcc_user.ConfigNode(urllib2.unquote(node).decode('utf8').encode('gbk'), core_limit)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ConfigModel exception - %s' % e)
            raise self._TransException(e)
        
        return 0
    
    def get_module_by_name(self, trunk, name, version):
        result = []
        try:
            pcc_user.ListModuleByName(urllib2.unquote(trunk).decode('utf8').encode('gbk'),
                                      urllib2.unquote(name).decode('utf8').encode('gbk'), version, result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListModuleByName exception - %s' % e)
            raise self._TransException(e)
        
        return result
    
    def get_model_by_name(self, name, version):
        result = []
        try:
            pcc_user.ListModelByName(urllib2.unquote(name).encode('gbk'), version, result)
        except pcc_user.error, e:
            PCC_LOG.ERROR('[PCCProxy]-pcc_user.ListModelByName exception - %s' % e)
            raise self._TransException(e)
        
        return result
