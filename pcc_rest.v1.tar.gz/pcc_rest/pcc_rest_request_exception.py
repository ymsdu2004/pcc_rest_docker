#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_request_exception.py
# 2014-10-31
#

from pcc_rest_exception import PccBaseException

class BadRequest(PccBaseException):
    def __init__(self, code, message):
        PccBaseException.__init__(self, code, message, '400 BAD REQUEST')

class UnAuthorized(PccBaseException):
    def __init__(self, code, message):
        PccBaseException.__init__(self, code, message, '401 UNAUTHORIZED')

class Forbidden(PccBaseException):
    def __init__(self, code, message):
        PccBaseException.__init__(self, code, message, '403 FORBIDDEN')

class NotFound(PccBaseException):
    def __init__(self, code, message):
        PccBaseException.__init__(self, code, message, '404 NOT FOUND')

class MethodNotAllowed(PccBaseException):
    def __init__(self, code, message):
        PccBaseException.__init__(self, code, message, '405 Method Not Allowed')
        
class NotAcceptable(PccBaseException):
    def __init__(self, code, message):
        PccBaseException.__init__(self, code, message, '406 Not Acceptable')
        
class InternalFailure(PccBaseException):
    def __init__(self, code, message):
        PccBaseException.__init__(self, code, message, '500 INTERNAL SERVER ERROR')
        
class UnImplemented(PccBaseException):
    def __init__(self, code, message):
        PccBaseException.__init__(self, code, message, '501 Not Implemented')
        
        
        