#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_application.py
# 2014-10-24
#

import sys
import urllib2
from pcc_proxy import PCCProxy
from pcc_rest_exception import PccBaseException
from pcc_rest_concrete_exception import InternalFatal
from pcc_rest_ret_content_tmpl import *
#from pcc_rest_request_handler import *
from rest_url_router import URLRouter
from pcc_rest_url_handler import *
from pcc_rest_logger import PCC_LOG

pcc_rest_url_router_pattern = \
{
    '/pcc': pcc_rest_main_handler,
    '/pcc/system': pcc_rest_system_handler,
    '/pcc/system/property': pcc_rest_system_property_handler,
    '/pcc/system/models': pcc_rest_system_models_handler,
    '/pcc/system/models/[^/]+': pcc_rest_specific_model_handler,
    '/pcc/system/models/.+/modules': pcc_rest_specific_model_modules_handler,
    '/pcc/system/time': pcc_rest_time_handler,
    '/pcc/system/centers': pcc_rest_centers_handler,
    '/pcc/system/centers/.+': pcc_rest_specific_center_handler,
    '/pcc/system/nodes': pcc_rest_nodes_handler,
    '/pcc/system/nodes/.+': pcc_rest_specific_node_handler,
    '/pcc/signature': pcc_rest_signature_handler,
    '/pcc/signature/.+': pcc_rest_specific_signature_handler,
    '/pcc/jobs': pcc_rest_jobs_handler,
    #'/pcc/jobs/running': pcc_rest_running_jobs_handler,
    #'/pcc/jobs/running/(\d+)': pcc_rest_specific_running_job_handler,
    #'/pcc/jobs/running/(\d+)/tasks': pcc_rest_running_job_tasks_handler,
    #'/pcc/jobs/running/(\d+)/tasks/(\d+)': pcc_rest_specific_running_job_task_handler,
    #'/pcc/jobs/finished': pcc_rest_finished_jobs_handler,
    #'/pcc/jobs/finished/(\d+)': pcc_rest_specific_finished_job_handler,
    #'/pcc/jobs/finished/(\d+)/tasks': pcc_rest_finished_job_tasks_handler,
    #'/pcc/jobs/finished/(\d+)/tasks/(\d+)': pcc_rest_specific_finished_job_task_handler,
    '/pcc/jobs/(\d+)': pcc_rest_specific_job_handler,
    '/pcc/jobs/(\d+)/tasks': pcc_rest_job_tasks_handler,
    '/pcc/jobs/(\d+)/tasks/(\d+)': pcc_rest_specific_job_task_handler,
    '/pcc/trunks': pcc_rest_trunks_handler,
    '/pcc/trunks/[^/]+': pcc_rest_specific_trunk_handler,
    '/pcc/trunks/.+/modules': pcc_rest_specific_trunk_modules_handler,
    '/pcc/trunks/.+/modules/.+': pcc_rest_specific_trunk_specific_module_handler,
    '/pcc/trunks/.+/auth': pcc_rest_auth_center_handler
}

class PccRestApplication(object):
    
    def __init__(self, ip, port):
        
        try:
            PCCProxy().prepare(ip, port)
            PCCProxy().open()
        except PccBaseException, e:
            PCC_LOG.ERROR('[PccRestApplication] Init pcc proxy fail: %s' %e)
        
        try:
            self.router = URLRouter(pcc_rest_url_router_pattern)
        except PccBaseException, e:
            PCC_LOG.ERROR('Create url router fail, %d[%s]' % (e.code, e.message))
            self.router = None
            
    def __call__(self, environ, start_response):
        
        query_string = environ.get('QUERY_STRING', '')
        method = environ.get('REQUEST_METHOD', '')
        path = environ.get('PATH_INFO', '')
        request = '%s %s%s' % (method, path, '?' + query_string if query_string else '')

        PCC_LOG.INFO('[PccRestApplication]: RECV request: %s' % urllib2.unquote(request))
        
        code = '200 OK'
        header = [('Content-Type', 'json')]
        content = ''
        
        try:
            if self.router:
                (code, header, content) = self.router(environ)
            else:
                raise InternalFatal('Internal error, no url router')
            
        except PccBaseException, e:
            code = e.status
            content = request_err_content_tmpl % (request, e.code, e.message)
        except BaseException, e:
            PCC_LOG.ERROR('[PccRestApplication]-!!!Exception!!! -> %s' % repr(sys.exc_info()))
            code = "500 INTERNAL SERVER ERROR"
            content = request_err_content_tmpl % (request, -1, e)

        start_response(code, header)
        PCC_LOG.INFO('-'*50)
        PCC_LOG.INFO(code)
        PCC_LOG.INFO(header)
        PCC_LOG.INFO('-'*50)
        return [content.decode('gbk').encode('utf8')]
        
