#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_concrete_exception.py
# 2014-10-31
#

from pcc_rest_request_exception import BadRequest
from pcc_rest_request_exception import NotFound
from pcc_rest_request_exception import InternalFailure
from pcc_rest_request_exception import UnAuthorized
from pcc_rest_request_exception import Forbidden
from pcc_rest_request_exception import UnImplemented
from pcc_rest_request_exception import MethodNotAllowed

class ErrorCode(object):
    __errBase               = -60000
    
    invalidQueryString      = __errBase - 1
    invalidUrl              = __errBase - 2
    resourceNotFound        = __errBase - 3
    fileUpload              = __errBase - 4
    fileDownload            = __errBase - 5
    invalidMethod           = __errBase - 6
    valueOverRange          = __errBase - 7
    invalidValue            = __errBase - 8
    missingQueryString      = __errBase - 9
    missingFormParams       = __errBase - 10
    missingContent          = __errBase - 11
    invalidContent          = __errBase - 12
    
    invalidParamType        = __errBase - 13
    internalFatal           = __errBase - 14
    invalidUser             = __errBase - 15
    invalidPasswd           = __errBase - 16
    signatureExpired        = __errBase - 17
    noAuthority             = __errBase - 18
    needSignature           = __errBase - 19
    userAlreadyExist        = __errBase - 20
    operationDenied         = __errBase - 21
    unhandledException      = __errBase - 22
    
    connUninitialized       = __errBase - 23
    pccExecuteFail          = __errBase - 24
    unImplemented           = __errBase - 25

class InvalidQueryString(BadRequest):
    def __init__(self, message = 'Invalid Query String'):
        BadRequest.__init__(self, ErrorCode.invalidQueryString, message)
        
class InvalidUrl(BadRequest):
    def __init__(self, message = 'Invalid URL'):
        BadRequest.__init__(self, ErrorCode.invalidUrl, message)
        
class ResourceNotFound(NotFound):
    def __init__(self, message = 'Resource Not Found'):
        NotFound.__init__(self, ErrorCode.resourceNotFound, message)
        
class FileUpload(InternalFailure):
    def __init__(self, message = 'File Upload Fail'):
        InternalFailure.__init__(self, ErrorCode.fileUpload, message)
        
class FileDownload(InternalFailure):
    def __init__(self, message = 'File Download Fail'):
        InternalFailure.__init__(self, ErrorCode.fileUpload, message)
        
class InvalidMethod(MethodNotAllowed):
    def __init__(self, message = 'Invalid Method'):
        MethodNotAllowed.__init__(self, ErrorCode.invalidMethod, message)
        
class ValueOverRange(BadRequest):
    def __init__(self, message = 'Query String Value Over Range'):
        BadRequest.__init__(self, ErrorCode.valueOverRange, message)
        
class InvalidValue(BadRequest):
    def __init__(self, message = 'Invalid Query String Value'):
        BadRequest.__init__(self, ErrorCode.invalidValue, message)
        
class MissingQueryString(BadRequest):
    def __init__(self, message = 'Need Query String'):
        BadRequest.__init__(self, ErrorCode.missingQueryString, message)
        
class MissingFormParams(BadRequest):
    def __init__(self, message = 'Need Form Parameter'):
        BadRequest.__init__(self, ErrorCode.missingFormParams, message)
        
class MissingContent(BadRequest):
    def __init__(self, message = 'Need Content Body'):
        BadRequest.__init__(self, ErrorCode.missingContent, message)
        
class InvalidContent(BadRequest):
    def __init__(self, message = 'Unknown Content body'):
        BadRequest.__init__(self, ErrorCode.invalidContent, message)
        
class InvalidParamType(InternalFailure):
    def __init__(self, message = 'Invalid Parameter Type'):
        InternalFailure.__init__(self, ErrorCode.invalidParamType, message)
        
class InternalFatal(InternalFailure):
    def __init__(self, message = 'Internal Fatal Error'):
        InternalFailure.__init__(self, ErrorCode.invalidParamType, message)
        
class InvalidUser(UnAuthorized):
    def __init__(self, message = 'Invalid User'):
        UnAuthorized.__init__(self, ErrorCode.invalidUser, message)
        
class InvalidPasswd(UnAuthorized):
    def __init__(self, message = 'Invalid Password'):
        UnAuthorized.__init__(self, ErrorCode.invalidPasswd, message)
        
class SignatureExpired(UnAuthorized):
    def __init__(self, message = 'Signature Expired'):
        UnAuthorized.__init__(self, ErrorCode.signatureExpired, message)
        
class NoAuthority(UnAuthorized):
    def __init__(self, message = 'No Authority'):
        UnAuthorized.__init__(self, ErrorCode.noAuthority, message)

class NeedSignature(UnAuthorized):
    def __init__(self, message = 'Need Signature'):
        UnAuthorized.__init__(self, ErrorCode.needSignature, message)
        
class UserAlreadyExist(InternalFailure):
    def __init__(self, message = 'User Already Exist, Try Another One'):
        InternalFailure.__init__(self, ErrorCode.userAlreadyExist, message)
        
class OperationDenied(Forbidden):
    def __init__(self, message = 'Operation Denied'):
        Forbidden.__init__(self, ErrorCode.operationDenied, message)
        
class UnhandledException(InternalFailure):
    def __init__(self, message = 'Internal Unhandled Exception'):
        InternalFailure.__init__(self, ErrorCode.unhandledException, message)
        
class ConnUninitialized(InternalFailure):
    def __init__(self, message = 'Connector Uninitialized'):
        InternalFailure.__init__(self, ErrorCode.connUninitialized, message)
        
class PCCExecuteFail(InternalFailure):
    def __init__(self, message = 'PCC Execute Fail'):
        InternalFailure.__init__(self, ErrorCode.pccExecuteFail, message)
        
class APINotImplemented(UnImplemented):
    def __init__(self, message = 'API NOT Implemented'):
        UnImplemented.__init__(self, ErrorCode.unImplemented, message)
        
        