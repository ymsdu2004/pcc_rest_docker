#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# rest_util.py
# 2014-10-24
#

# singleton decorator
'''
def singleton(cls, *args, **kw):
    instances = {}
    def _singleton():
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]
    return _singleton
'''

class Singleton(object):  
    def __new__(cls, *args, **kw):  
        if not hasattr(cls, '_instance'):  
            orig = super(Singleton, cls)  
            cls._instance = orig.__new__(cls, *args, **kw)  
        return cls._instance 

def url_path_split(path):
    '''
    split path by url separator('/'), return a path node list
    '''
    return path.strip().strip('/').split('/')

def query_string_parse(query_string):
    '''
    parse query string to a dict
    return a dict, key is name, value is a list(because each parameter can be multi-values)
    Note: There are two kinds of multi-values format such as : 
    a=1,2,3,4&b=2 or a=1&a=2&a=3&a=4&b=2
    the result is same: {'a': ['1', '2', '3', '4'], 'b': [2]} 
    '''
    param_dict = {}
    params = query_string.split('&')
    for pair in params:
        k_v = pair.split('=')
        if len(k_v) == 2:
            values = k_v[1].split(',')
            if k_v[0] not in param_dict:
                param_dict[k_v[0]] = values
            else:
                for i in values:
                    param_dict[k_v[0]].append(i)
            
    return param_dict

def parse_name_version_from_string(str):
    idx = str.rfind('-')
    if idx != -1 and idx != 0 and idx != len(str)-1:
        return str[0:idx], str[idx+1:]
    
    return '', ''

if __name__ == '__main__':
    
    print '-------- TEST url_path_split --------'
    path1 = '/pcc/user/job'
    path2 = '/pcc/user/job/'
    path3 = '    /pcc/user/job/'
    path4 = '    /pcc/user/job/      '
    path5 = '    /pcc/user/job'
    path6 = '    /pcc/user/job      '
    
    if url_path_split(path1) == \
        url_path_split(path2) == \
        url_path_split(path3) == \
        url_path_split(path4) == \
        url_path_split(path5) == \
        url_path_split(path6) == \
        ['pcc', 'user', 'job']:
        print 'Success'
    else:
        print 'Fail'
        
    print '------------------------------------' 
    
    print '------ TEST query_string_parse ------'
    query_string1 = 'a=1,2,3,4&b=2'
    query_string2 = 'a=1&a=2&a=3&a=4&b=2'
    
    if query_string_parse(query_string1) == \
        query_string_parse(query_string2) == \
        {'a': ['1', '2', '3', '4'], 'b': ['2']}:
        print 'Success'
    else:
        print 'Fail'
        
    print '------------------------------------' 
    
    print '------ TEST parse_name_version_from_string ------'
    name_version_1 = 'hello-1.2.0'
    name_version_2 = '-he---llo-1.2.0'
    name_version_3 = '-1.2.0'
    name_version_4 = 'hello-'
    name_version_5 = 'hello'
    
    if parse_name_version_from_string(name_version_1) == ('hello', '1.2.0') and \
        parse_name_version_from_string(name_version_2) == ('-he---llo', '1.2.0') and \
        parse_name_version_from_string(name_version_3) == ('', '') and \
        parse_name_version_from_string(name_version_4) == ('', '') and \
        parse_name_version_from_string(name_version_5) == ('', '') :
        print 'Success'
    else:
        print 'Fail'
        
    print '------------------------------------' 
    