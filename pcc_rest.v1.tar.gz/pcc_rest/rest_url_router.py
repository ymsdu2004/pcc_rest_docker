#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# rest_url_router.py
# a simple url dispatch for rest api
# 2014-10-24
#

import re
from pcc_rest_concrete_exception import *

# restfull resource url router
class URLRouter(object):
    '''
    A simple http url(query string not included) router, 
    which means: a url corresponding to a handle function(or any callable object),
    moreover, the handler function or callable object should return a tupe: (code, header, content)
    '''
    
    def __init__(self, init_entries_dict):
        '''
        construct a URLRouter object
        @init_entries: initial url router entries, 
         Note: it must be a dict like {'url_patern_string': callable object, ...}
        '''
        self.url_handler_pattern = {}
        
        # it must be a dict object
        if not isinstance(init_entries_dict, dict):
            raise InvalidParamType()
        
        for key in init_entries_dict:
            if callable(init_entries_dict[key]): # we ignore invalid entry
                self.url_handler_pattern[key] = init_entries_dict[key]
                
    def addEntry(self, entries_dict):
        '''
        Add entries for URLRouter object
        @entries_dict: initial url router entries, 
        Note: it must be a dict like {'url_patern_string': callable object, ...}
        '''
        if not isinstance(entries_dict, dict):
            raise InvalidParamType()
        
        for key in entries_dict:
            if callable(entries_dict[key]): 
                self.url_handler_pattern[key] = entries_dict[key]
    
    def _noneMatchedUrl(self, environ):
        raise ResourceNotFound()
    
    def _handlerMatch(self, url):
        url = url.strip().rstrip('/')
        handler = self._noneMatchedUrl
        for pattern in self.url_handler_pattern:
            if re.match('^' + pattern + '$', url):
                handler = self.url_handler_pattern[pattern]
                
        return handler
                
    def __call__(self, environ):
        return self._handlerMatch(environ.get('PATH_INFO', ''))(environ)
    