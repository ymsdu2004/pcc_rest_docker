#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_ret_content_tmpl.py
# 2014-10-24
#

request_err_content_tmpl = \
'''
{
    "error":
    {
        "request": "%s",
        "error_code": %d,
        "message": "%s"
    }
}
''' 

get_signature_content_tmpl = \
'''
{
    "result":
    {
        "signature":
        {
            "token": "%s",
            "timeout": %d
        }
    }
}
'''

check_signature_valid_content_tmpl = \
'''
{
    "result":
    {
        "token":
        {
            "valid": %s,
            "timeout": %d
        }
    }
}
'''

get_pcc_property_content_tmpl = \
'''
{
    "result":
    {
        "properties": %s
    }
}
'''

get_pcc_single_node_partial_content_tmpl = \
'''
{
    "result":
    {
        "node": %s
    }
}
'''
get_pcc_nodes_partial_content_tmpl = \
'''
{
    "result":
    {
        "nodes": %s
    }
}
'''

query_jobs_partial_content_tmpl = \
'''
{
    "result":
    {
        "jobs": %s
    }
}
'''

query_single_job_partial_content_tmpl = \
'''
{
    "result":
    {
        "job": %s
    }
}
'''

list_models_partial_content_tmpl = \
'''
{
    "result":
    {
        "models": %s
    }
}
'''

list_single_model_partial_content_tmpl = \
'''
{
    "result":
    {
        "model": %s
    }
}
'''

list_module_partial_content_tmpl = \
'''
{
    "result":
    {
        "modules": %s
    }
}
'''

get_module_info_partial_content_tmpl = \
'''
{
    "result":
    {
        "module": %s
    }
}
'''

list_auth_center_partial_content_tmpl = \
'''
{
    "result":
    {
        "auth_centers": %s
    }
}
'''

list_trunk_partial_content_tmpl = \
'''
{
    "result":
    {
        "trunks": %s
    }
}
'''

commit_job_content_tmpl = \
'''
{
    "result":
    {
        "job_info":
        {
            "key": %d
        }
    }
}
'''
