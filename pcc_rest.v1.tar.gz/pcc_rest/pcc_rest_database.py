#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_database.py
# 2014-11-11
#

import sqlite3

class RestDB(object):
    '''
    '''
    
    def __init__(self):
        self.conn = None
    
    def open(self, name):
        self.conn = sqlite3.connect(name)
        #conn.setTimeout()
        
    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None
            
    
            