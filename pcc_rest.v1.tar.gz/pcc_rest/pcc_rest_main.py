#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_main.py
# WSGI application main entry for pcc http-restfull api
# what is WSGI, please reference PEP333:
# http://legacy.python.org/dev/peps/pep-0333/
# 2014-10-24
#

import sys
import getopt
import os
import time
#from flup.server.fcgi import WSGIServer
from wsgiref.simple_server import make_server
from pcc_rest_application import PccRestApplication
from application_info import AppInfo
from getopt import GetoptError
from pcc_rest_logger import PCC_LOG

pcc_rest_logo_tmpl = \
'''
++++++++  ++++++  ++++++
+      + +       +        PCC-REST %s (%d)
+      + +       +        Start at %s
++++++++ +       +        by %s
+        +       +        Port: %d
+        +       +        PID: %d
+         ++++++  ++++++
'''

def pcc_rest_logo(version, revision, time, builder, port, pid):
    print pcc_rest_logo_tmpl % (version, revision, time, builder, port, pid)

def pcc_rest_usage():
    print 'there are two kind format options'
    print '%s\t%s' % ('--version(-v)', 'show version')
    print '%s\t%s' % ('--help(-h)', 'usage information')
    print '%s\t%s' % ('--ip(-i)', 'binded ip address')
    print '%s\t%s' % ('--port(-p)', 'service network port')
    print '%s\t%s' % ('--pcc_ip(-a)', 'pcc server address')
    print '%s\t%s' % ('--pcc_port(-o)', 'pcc server network port')
    
def pcc_rest_version_information():
    print 'Application:', AppInfo.NAME
    print 'Version:', AppInfo.VERSION
    print 'Revision:', AppInfo.REVISION 
    
if __name__ == '__main__':
    PCC_LOG.INFO('PCC REST WSGI Start up...')
    try:
        options, args = getopt.getopt(sys.argv[1:], 'hvp:i:a:o:', ['version', 'help', 'ip=', 'port=', 'pcc_ip=', 'pcc_port='])
    except getopt.GetoptError, e:
        PCC_LOG.ERROR('Options parse fail[%s], exiting...' % e)
        sys.exit()
        
    ip = '0.0.0.0'
    port = AppInfo.DEFAULT_PORT
    pcc_ip = '127.0.0.1'
    pcc_port = 9011
    
    for name, value in options:
        if name in ['-h', '--help']:
            pcc_rest_usage()
            sys.exit()
        if name in ['-v', '--version']:
            pcc_rest_version_information()
            sys.exit()
        if name in ['-i', '--ip']:
            ip = value
        if name in ['-p', '--port']:
            port = int(value)
        if name in ['-a', '--pcc_ip']:
            pcc_ip = value
        if name in ['-o', '--pcc_port']:
            pcc_port = int(value)
    
    pcc_rest_logo(AppInfo.VERSION, AppInfo.REVISION, time.strftime('%Y-%m-%d %A %X',time.localtime(time.time()))  , AppInfo.BUILDER, port, os.getpid())
    
    PCC_LOG.INFO('PCC Server (%s, %d)' % (pcc_ip, pcc_port))
    PCC_LOG.INFO('Now, it can accept request at (%s, %d)...' % (ip, port))
    
    try:
        app = PccRestApplication(pcc_ip, pcc_port)
        #WSGIServer(app, bindAddress = (ip, port)).run()
        make_server(ip, port, app).serve_forever()
    except:
        PCC_LOG.ERROR('[__main__]-!!!Exception!!! -> %s' % repr(sys.exc_info()))
    
    