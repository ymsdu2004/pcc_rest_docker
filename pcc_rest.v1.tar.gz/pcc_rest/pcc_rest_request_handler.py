#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# pcc_rest_request_handler.py
# 2014-10-24
#

import os
import urlparse
import urllib2
import json
import rest_util
from pcc_rest_concrete_api import *
from pcc_rest_ret_content_tmpl import *
from rest_file_uploader import post_form_content_handler2
from pcc_rest_concrete_exception import *
from pcc_rest_exception import PccBaseException

def pcc_rest_main_page_handler(environ):
    print '[URLRouter]: pcc_rest_main_page_handler'
    
    code = '200 OK'
    header = [('Content-Type', 'json')]
    content = ''
    
    return (code, header, content)

def pcc_rest_auth_handler(environ):
    print '[URLRouter]: pcc_rest_auth_handler'
    
    code = '200 OK'
    header = [('Content-Type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    try:
        # get api signature
        if path_nodes[-1] == 'auth':
            param_dict = rest_util.query_string_parse(query_string)
            if 'user' in param_dict and 'passwd' in param_dict:
                signature, timeout = pcc_rest_get_signature(param_dict.get('user')[0], param_dict.get('passwd')[0])
                content = get_signature_content_tmpl % (signature, timeout)
            else:
                raise InvalidQueryString('Unknown query parameter: %s' % query_string)
                        
        elif path_nodes[-2] == 'auth':
            signature = path_nodes[-1]
            if method == 'GET': # is api signature valid
                timeout = pcc_rest_get_signature_timeout(signature)
                content = check_signature_valid_content_tmpl % ('True' if timeout > 0 else 'False', timeout)
            elif method == "DELETE": # unregister an api signature
                pcc_rest_giveback_signature(signature)
            else:
                raise InvalidMethod("Unsupported request[%s] method for this url" % (method))
        else:
            raise ResourceNotFound("Unknown resource url")
        
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        print 'pcc_rest_auth_handler -> successful'

    return (code, header, content)

def pcc_rest_property_handler(environ):
    print '[URLRouter]: pcc_rest_property_handler'
    
    code = '200 OK'
    header = [('Content-Type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    try:
        if query_string:
            raise InvalidQueryString('Unknown query string for this resource')
        
        if method != 'GET':
            raise InvalidMethod('No %s method for this resource' % method)
        
        if path_nodes[-1] != 'property':
            raise InvalidUrl()
        
        content = get_pcc_property_content_tmpl % json.dumps(pcc_rest_get_property(), ensure_ascii=False, indent = 2)
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        print 'pcc_rest_property_handler -> successful'
    
    return (code, header, content)

def pcc_rest_node_handler(environ):
    print '[URLRouter]: pcc_rest_node_handler'
    
    code = '200 OK'
    header = [('Content-Type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        if query_string and (not len(param_dict)):
            raise InvalidQueryString('Invalid parameter format')
    
        permit_param = set(['type', 'core_limit'])
        if not (set(param_dict.keys()) < permit_param):
            raise InvalidQueryString('Unknown parameters')
            
        if path_nodes[-1] == 'node':
            if method == 'GET':
                if param_dict and 'type' not in param_dict:
                    raise InvalidQueryString('Invalid query string for GET method on this resource')
                info = pcc_rest_get_nodes_info(param_dict.get('type', ['static'])[0])
                content = get_pcc_nodes_partial_content_tmpl % json.dumps(info, indent = 2)
            else:
                raise InvalidMethod('%s method is not supported by this url' % method)
            
        elif path_nodes[-2] == 'node':
            node = path_nodes[-1]
            if method == 'POST' and 'core_limit' in param_dict: # config node 
                if not param_dict.get('core_limit')[0].isdigit():
                    raise InvalidValue('core_limit parameter must be a digit string')
                pcc_rest_cfg_node(node, int(param_dict.get('core_limit')[0]))
                code = '202 ACCEPTED'
            elif method == 'GET': # get specific node information
                if param_dict and 'type' not in param_dict:
                    raise InvalidQueryString('Invalid query string for GET method on this resource')
                
                info = pcc_rest_get_single_node_info(node, param_dict.get('type', ['static'])[0])
                content = get_pcc_single_node_partial_content_tmpl % json.dumps(info, indent = 2)
            else:
                raise InvalidMethod('No matched resource for method %s request' % method)
        else:
            raise InvalidUrl('Unknown url for pcc node operation')
    
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        print 'pcc_rest_node_handler -> successful'
    
    return (code, header, content)

def pcc_rest_trunk_handler(environ):
    print '[URLRouter]: pcc_rest_trunk_handler'
    
    code = '200 OK'
    header = [('Content-Type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        if path_nodes[-1] == 'trunk':
            if method == 'GET': # list trunk
                limits = 0
                if 'max_results' in param_dict:
                    max_results = param_dict['max_results'][0]
                    if not max_results.isdigit():
                        raise InvalidQueryString('Parameter max should be a digit string')
                    limits = int(max_results)
                    
                infos = pcc_rest_list_trunks(limits)
                content = list_trunk_partial_content_tmpl % json.dumps(infos, ensure_ascii=False)
            elif method == 'PUT': # create a trunk
                if 'name' not in param_dict:
                    raise MissingQueryString('name is a must query string for creating trunk')
                
                if not param_dict.get('name', []):
                    raise InvalidValue()
                
                pcc_rest_add_trunk(param_dict.get('name')[0])
            else:
                raise InvalidMethod('Method %s is not valid for this resource' % method)
                
        elif path_nodes[-2] == 'trunk':
            if method == 'DELETE': # delete trunk
                name = path_nodes[-1]
                pcc_rest_delete_trunk(name)
            else:
                raise InvalidMethod('%s method is invalid for this url' % method)
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        print 'pcc_rest_trunk_handler -> successful'
        
    #header.append(('Content-Type', len(content)))
    
    return (code, header, content)

def pcc_rest_module_handler(environ):
    print '[URLRouter]: pcc_rest_module_handler'
    
    code = '200 OK'
    header = [('Content-Type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        if path_nodes[-1] == 'module':
            if method == 'GET':
                if 'trunk' in param_dict:
                    limits = 0
                    if 'max_results' in param_dict:
                        max_results = param_dict['max_results'][0]
                        if not max_results.isdigit():
                            raise InvalidQueryString('Parameter max should be a digit string')
                    limits = int(max_results)
                    info = pcc_rest_list_modules_in_trunk(param_dict.get('trunk')[0], limits)
                    content = list_module_partial_content_tmpl % json.dumps(info, ensure_ascii=False, indent = 2)
                elif 'model' in param_dict and 'version' in param_dict:
                    info = pcc_rest_get_module_info(param_dict.get('model')[0], param_dict.get('version')[0])
                    content = get_module_info_partial_content_tmpl % json.dumps(info, ensure_ascii=False, indent = 2)
                elif not query_string:
                    raise MissingQueryString('trunk or name+version parameter is a must')
                else:
                    raise InvalidQueryString('Unsupported parameters')
            elif method == 'POST': # add module
                validParams = ['trunk', 'model', 'name', 'version', 'pattern', \
                               'filetype', 'type', 'latency', 'platform', 'size', 'description', 'time']
                
                for i in validParams:
                    if i not in param_dict:
                        raise MissingQueryString('Parameter %s should be given' % i)
                    if not param_dict[i]:
                        raise InvalidValue('Parameter %s value invalid' % i)
                    
                trunk = param_dict['trunk'][0]
                model_key = param_dict['model'][0]
                
                properties = {}
                properties['name'] = param_dict['name'][0]
                properties['version'] = param_dict['version'][0]
                properties['pattern']  = int(param_dict['pattern'][0])
                properties['filetype'] = int(param_dict['filetype'][0])
                properties['type'] = int(param_dict['type'][0])
                properties['latency'] = int(param_dict['latency'][0])
                properties['platform'] = long(param_dict['platform'][0])
                properties['size'] = long(param_dict['size'][0])
                properties['time'] = long(param_dict['time'][0])
                properties['description'] = urllib2.unquote(param_dict['description'][0]).decode('utf8').encode('gbk')
                
                # parse file
                content_type = environ.get('CONTENT_TYPE')
                idx = content_type.find('boundary=')
                if (idx < 0):
                    raise MissingFormParams('Model binary file should be upload by form parameter')
                
                boundary = content_type[idx + 9:]
                collections = post_form_content_handler2(environ.get('wsgi.input'), boundary)
                files = []
                if 'files' in collections:
                    for filename in collections['files']:
                        print 'RECV file:', filename
                        files.append(filename)
                else:
                    raise FileUpload('Parse file content fail')
                
                pcc_rest_add_module(trunk, int(model_key), properties, files)
                code = '201 CREATED'
                
            else:
                raise InvalidMethod('%s method is invalid for this url' % method)
        elif path_nodes[-2] == 'module':
            key = path_nodes[-1]
            if not key.isdigit():
                raise InvalidValue('model key must be a digit string')
            if method == 'DELETE': # delete a module
                
                trunk = None
                if 'trunk' in param_dict:
                    if not param_dict['trunk']:
                        raise InvalidValue('trunk parameter is given, but it should not be null');
                    
                    trunk = param_dict['trunk'][0]
                    
                pcc_rest_delete_module(int(key), trunk)
            else:
                raise InvalidMethod('No %s method for this resource' % method)
                
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        print 'pcc_rest_module_handler -> successful'
    
    return (code, header, content)

def pcc_rest_model_handler(environ):
    print '[URLRouter]: pcc_rest_model_handler'
    
    code = '200 OK'
    header = [('Content-Type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        if path_nodes[-1] == 'model':
            if method == 'GET': # list models
                reports = pcc_rest_list_models()
                content = list_models_partial_content_tmpl % json.dumps(reports, indent = 2)
            elif method == 'POST': # add model
                validParam = ['name', 'version', 'ip', 'port', 'description', 'time']
                
                for i in validParam:
                    if i not in param_dict:
                        raise InvalidQueryString('Query string %s is needed by adding model' % i)
                    if not param_dict.get(i, []):
                        raise InvalidValue('Unknown query string value %s', i)
                
                for key in param_dict:
                    if key not in validParam:
                        raise InvalidQueryString('Unknown parameter %s' % key) 
                    
                # parse file
                content_type = environ.get('CONTENT_TYPE')
                idx = content_type.find('boundary=')
                if (idx < 0):
                    raise MissingFormParams('Model binary file should be upload by form parameter')
                
                boundary = content_type[idx + 9:]
                collections = post_form_content_handler2(environ.get('wsgi.input'), boundary)
                files = []
                if 'files' in collections and collections['files']:
                    for filename in collections['files']:
                        print 'RECV file:', filename
                        files.append(filename)
                else:
                    raise FileUpload('Parse file content fail')
                
                if not param_dict['port'][0].isdigit():
                    raise InvalidValue('Parameter port must digit string')
                
                if not param_dict['time'][0].isdigit():
                    raise InvalidValue('Parameter time must digit string') 
                
                properties = {}
                properties['name'] = param_dict['name'][0]
                properties['version']  = param_dict['version'][0]
                properties['ip']  = param_dict['ip'][0]
                properties['port'] = int(param_dict['port'][0])
                properties['description'] = param_dict['description'][0]
                properties['time'] = long(param_dict['time'][0])
                        
                pcc_rest_add_model(properties, files)
                code = '201 CREATED'

            elif method == 'PUT': # config model port
                if 'name' in param_dict and 'version' in param_dict and 'port' in param_dict:
                    if not param_dict.get('port')[0].isdigit():
                        raise InvalidValue('port should be digit string')
                    pcc_rest_set_model_port(param_dict.get('name')[0], param_dict.get('version')[0], int(param_dict.get('port')[0]))
                    code = '202 ACCEPTED'
                else:
                    raise InvalidQueryString("parameter name, version and port should be given")
            else:
                raise InvalidMethod('%s method is not valid for this url' % method)
                    
        elif path_nodes[-2] == 'model':
            model_key = path_nodes[-1]
            if not model_key.isdigit():
                raise InvalidValue('model key should be a digit string')
            
            if method == 'DELETE': # delete model
                if query_string:
                    raise InvalidQueryString("query string '%s' unsupported by 'DELETE' method for this resource" % query_string)
                pcc_rest_delete_model(int(model_key))
            elif method == 'POST': # update model
                validParam = ['name', 'version', 'ip', 'port', 'description', 'time']
                
                for i in validParam:
                    if i not in param_dict:
                        raise InvalidQueryString('Query string %s is needed by adding model' % i)
                    if not param_dict.get(i, []):
                        raise InvalidValue('Unknown query string value %s', i)
                
                for key in param_dict:
                    if key not in validParam:
                        raise InvalidQueryString('Unknown parameter %s' % key) 
                    
                # parse file
                content_type = environ.get('CONTENT_TYPE')
                idx = content_type.find('boundary=')
                if (idx < 0):
                    raise MissingFormParams('Model binary file should be upload by form parameter')
                
                boundary = content_type[idx + 9:]
                collections = post_form_content_handler2(environ.get('wsgi.input'), boundary)
                files = []
                if 'files' in collections:
                    for filename in collections['files']:
                        print 'RECV file:', filename
                        files.append(filename)
                else:
                    raise FileUpload('Parse file content fail')
                
                if not param_dict['port'][0].isdigit():
                    raise InvalidValue('Parameter port must digit string')
                
                if not param_dict['time'][0].isdigit():
                    raise InvalidValue('Parameter time must digit string') 
                
                properties = {}
                properties['name'] = param_dict['name'][0]
                properties['version']  = param_dict['version'][0]
                properties['ip']  = param_dict['ip'][0]
                properties['port'] = int(param_dict['port'][0])
                properties['description'] = param_dict['description'][0]
                properties['time'] = long(param_dict['time'][0])
                
                pcc_rest_update_model(int(model_key), properties, files)
                code = '202 ACCEPTED'
                        
            else:
                raise InvalidMethod('%s method is not valid for this url' % method)
        else:
            pass
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        print 'pcc_rest_model_handler -> successful'
        
    return (code, header, content)

def pcc_rest_auth_center_handler(environ):
    print '[URLRouter]: pcc_rest_auth_center_handler'
    
    code = '200 OK'
    header = [('Content-Type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    '''
    request_body_size = int(environ.get('CONTENT_LENGTH', 0))
    request_body = environ['wsgi.input'].read(request_body_size)
    d = urlparse.parse_qsl(request_body)
    '''
    try:
        
        if not query_string:
            raise MissingQueryString('Operation on this resource need parameters')
        
        if not param_dict:
            raise InvalidQueryString(-10093, 'Parse query string %s fail' % query_string)
        
        if method == 'POST': # add auth center
            if len(param_dict) != 3:
                raise MissingQueryString('Parameters not enough for adding auth center')
            
            if 'trunk' in param_dict and 'name' in param_dict and 'version' in param_dict:
                # receive and save at local file system
                content_type = environ.get('CONTENT_TYPE')
                idx = content_type.find('boundary=')
                if (idx < 0):
                    raise MissingFormParams('Auth center binary file should be upload by form parameter')
                
                boundary = content_type[idx + 9:]
                collections = post_form_content_handler2(environ.get('wsgi.input'), boundary)
                if 'files' in collections:
                    for filename in collections['files']:
                        print 'RECV file:', filename
                        
                pcc_rest_add_auth_center(param_dict['trunk'][0], param_dict['name'][0], param_dict['version'][0], collections['files'])
                code = '201 CREATED'
            else:
                raise InvalidQueryString('Invalid query string for adding auth center')
            
        elif method == 'DELETE': # delete auth center
            if len(param_dict) == 1 and 'trunk' in param_dict: # delete auth center under specific trunk
                pcc_rest_delete_auth_center_by_trunk(param_dict.get('trunk')[0])
            elif len(param_dict) == 3 and 'trunk' in param_dict and 'name' in param_dict and 'version' in param_dict:
                pcc_rest_delete_auth_center(param_dict.get('trunk')[0], param_dict.get('name')[0], param_dict.get('version')[0])
            else:
                raise InvalidQueryString('Invalid query string for delete auth center')
            
        elif method == 'GET': # get auth center info
            if len(param_dict) == 1 and 'trunk' in param_dict:
                report = pcc_rest_list_auth_center(param_dict.get('trunk')[0])
                content = list_auth_center_partial_content_tmpl % json.dumps(report, indent = 2)
            else:
                raise InvalidQueryString('Invalid query string for get auth center information')
        else:
            raise InvalidMethod('%s method for this url is invalid' % method)
        
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        print 'pcc_rest_auth_center_handler -> successful'
    
    return (code, header, content)

def pcc_rest_job_handler(environ):
    print '[URLRouter]: pcc_rest_job_handler'
    
    code = '200 OK'
    header = [('Content-Type', 'json')]
    content = ''
    
    path_nodes = rest_util.url_path_split(environ['PATH_INFO'])
    query_string = environ.get('QUERY_STRING')
    method = environ.get('REQUEST_METHOD')
    
    param_dict = rest_util.query_string_parse(query_string)
    
    try:
        if path_nodes[-1] == 'job':
            if method == 'POST' and not query_string: # commit job
                request_body_size = int(environ.get('CONTENT_LENGTH', 0))
                if not request_body_size:
                    raise MissingContent('Job parameters should be given by json content body at committing job')
                
                request_body = environ['wsgi.input'].read(request_body_size)
                job_params = json.loads(request_body)
                valid_params = ['module_key', 'module_param', 'input_url', 'output_url', 'task_max_attempts']
                for i in valid_params:
                    if i not in job_params:
                        raise MissingContent('Commit job need parameter %s' % i)
                    
                out_key = pcc_rest_commit_job(job_params)
                content = commit_job_content_tmpl % out_key
                code = '201 CREATED'
            else:
                if 'id' in param_dict: # query jobs by ids
                    
                    if method != 'GET':
                        raise InvalidMethod('%s method is invalid for this resource' % method)
                    
                    if not len(param_dict.get('id')):
                        raise InvalidValue('Invalid query string, id should split by comma')
                        
                    jobs = []
                    [jobs.append(int(i)) for i in param_dict.get('id') if i.isdigit()]
                    if not jobs:
                        raise InvalidValue('Invalid query string, id should all digit string')
                    
                    reports = pcc_rest_query_jobs(jobs)
                    content = query_jobs_partial_content_tmpl % json.dumps(reports, ensure_ascii=False, indent = 2)
                    
                elif 'state' in param_dict: # query jobs by state
                    if method != 'GET':
                        raise InvalidMethod('%s method is invalid for this resource' % method)
                    
                    states = param_dict.get('state')
                    if not states:
                        raise InvalidValue('Invalid parameter, state should be split by comma')
                    
                    reports = pcc_rest_query_jobs_by_state(states)
                    content = query_jobs_partial_content_tmpl % json.dumps(reports, ensure_ascii=False, indent = 2)
                else:
                    raise InvalidQueryString('Parameter state or id should be given for this url')
        else:
            job_key = path_nodes[-1]
            if not job_key.isdigit():
                raise InvalidUrl('Invalid resource url, the last path must be digit job id');
            
            if method == 'GET': # query single job
                report = pcc_rest_query_single_job(int(job_key))
                content = query_single_job_partial_content_tmpl % json.dumps(report, ensure_ascii=False, indent = 2)
            elif method == 'DELETE': # delete specific job
                pcc_rest_delete_job(int(job_key))
            else: # invalid method for this url
                raise InvalidMethod('%s method is invalid for this resource' % method)
            
    except PccBaseException, e:
        code = e.status
        request = '%s %s%s' % (method, environ.get('PATH_INFO'), ('?' + query_string) if query_string else '')
        content = request_err_content_tmpl % (request, e.code, e.message)
    else:
        print 'pcc_rest_job_handler -> successful'
    
    return (code, header, content)
